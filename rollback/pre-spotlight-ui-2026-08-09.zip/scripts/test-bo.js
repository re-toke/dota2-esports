#!/usr/bin/env node
/**
 * BO 判定引擎单元测试（2026-08-04）
 * 覆盖：审核报告 P0-2/P0-3 兜底规则、方案 T1-T12、R4 阶段边界、parseBoFormat 变体（R7），
 *      以及（可选）1win / Games of the Future 真实数据回放。
 * 运行：node scripts/test-bo.js（已接入 npm test / test:all / precommit）
 */
const sources = require('../utils/sources.js');
const LP = require('../utils/liquipedia-parse.js');

let pass = 0, fail = 0;
function assert(name, cond, detail) {
  if (cond) { pass++; console.log('PASS  ' + name); }
  else { fail++; console.log('FAIL  ' + name + '  ->  ' + (detail || '')); }
}

// 造 OpenDota match（天辉队默认赢；team_id 1/2 作比分锚点）
function mk(id, seriesId, seriesType, win, teamA, teamB, start, extra) {
  return Object.assign({
    match_id: id, series_id: seriesId, series_type: seriesType,
    radiant_win: win, radiant_team_name: teamA, dire_team_name: teamB,
    radiant_team_id: 1, dire_team_id: 2,
    start_time: start, duration: 2400, radiant_score: 0, dire_score: 0
  }, extra || {});
}

// 全链路：OpenDota matches → groupSeries → buildBoContext → applyBo（模拟 league-detail 后处理）
function resolveAll(matches, leagueCtx) {
  const series = sources.groupSeries(matches);
  const ctx = sources.buildBoContext(series, leagueCtx);
  return series.map(function (s) { return sources.applyBo(s, ctx); });
}

// LP 形状 series（等价 league-detail liqSeries 映射产物：games=[], declaredBo 可选）
function lpSeries(opts) {
  return Object.assign({
    key: 'liq-test', games: [], scoreA: 0, scoreB: 0,
    boType: opts.declaredBo || 'BO1', declaredBo: opts.declaredBo || null,
    seriesType: null, phase: opts.phase || 'recent',
    section: opts.section || '', stageLabel: opts.section || '',
    radiantName: 'TeamA', direTeamName: 'TeamB', lastTime: opts.lastTime || 0
  }, opts);
}

// ===== parseBoFormat 变体（R7）=====
(function () {
  const o1 = LP.parseBoFormat('==Format==\n**All matches are {{Abbr/Bo2}}\n**Grand Final is {{Abbr/Bo5}}, all other matches are {{Abbr/Bo3}}');
  assert('parseBoFormat: 1win 样例 group=BO2', o1.group === 'BO2', JSON.stringify(o1));
  assert('parseBoFormat: 1win 样例 playoff=BO3', o1.playoff === 'BO3', JSON.stringify(o1));
  assert('parseBoFormat: 1win 样例 grandFinal=BO5', o1.grandFinal === 'BO5', JSON.stringify(o1));
  const o2 = LP.parseBoFormat('|format=Group Stage: Bo2 Round Robin<br>Playoffs: Bo3');
  assert('parseBoFormat: infobox 变体 group=BO2', o2.group === 'BO2', JSON.stringify(o2));
  assert('parseBoFormat: infobox 变体 playoff=BO3', o2.playoff === 'BO3', JSON.stringify(o2));
  const o3 = LP.parseBoFormat('==Format==\nGroup Stage matches are best of 2');
  assert('parseBoFormat: best of 文本 → BO2', o3.group === 'BO2', JSON.stringify(o3));
  const o4 = LP.parseBoFormat('');
  assert('parseBoFormat: 空输入 → 全 null', o4.group === null && o4.playoff === null && o4.grandFinal === null, JSON.stringify(o4));
})();

// ===== T1/T2：1win 小组赛 series_type=3（OpenDota 实证 BO2=3）=====
(function () {
  const base = 1785369600; // 2026-07-30
  const list = resolveAll([
    mk(1, 100, 3, true, 'A', 'B', base),
    mk(2, 100, 3, true, 'A', 'B', base + 7200),        // 2:0 横扫
    mk(3, 101, 3, true, 'C', 'D', base + 86400),
    mk(4, 101, 3, false, 'C', 'D', base + 86400 + 7200) // 1:1 平局
  ]);
  const s100 = list.find(function (s) { return s.key === 's100'; });
  const s101 = list.find(function (s) { return s.key === 's101'; });
  assert('T1: series_type=3 且 2:0 → BO2（不再误判 BO3）', s100.boType === 'BO2', '实际: ' + (s100 && s100.boType));
  assert('T2: series_type=3 且 1:1 → BO2', s101.boType === 'BO2', '实际: ' + (s101 && s101.boType));
})();

// ===== T3/T4：GotF 小组赛 series_type=1 + 段内 1:1 自证（S4 纠偏）=====
(function () {
  const base = 1785369600;
  const list = resolveAll([
    mk(10, 200, 1, true, 'X', 'Y', base),
    mk(11, 200, 1, true, 'X', 'Y', base + 7200),        // 2:0 st=1（疑 BO3 横扫）
    mk(12, 201, 1, true, 'P', 'Q', base + 3600),
    mk(13, 201, 1, false, 'P', 'Q', base + 10800)        // 1:1 st=1（BO2 铁证）
  ]);
  const s200 = list.find(function (s) { return s.key === 's200'; });
  const s201 = list.find(function (s) { return s.key === 's201'; });
  assert('T3: series_type=1 2:0 + 同段 1:1 自证 → BO2（GotF 场景）', s200.boType === 'BO2', '实际: ' + (s200 && s200.boType));
  assert('T4: series_type=1 1:1 → BO2', s201.boType === 'BO2', '实际: ' + (s201 && s201.boType));
})();

// ===== T5/T6/T7/T8：BO1/BO3/BO5 常规 =====
(function () {
  const base = 1785369600;
  const bo1 = resolveAll([mk(30, 0, 0, true, 'A', 'B', base)]);
  assert('T5: series_type=0 单场 1:0 → BO1', bo1[0].boType === 'BO1', '实际: ' + bo1[0].boType);

  const bo3 = resolveAll([
    mk(40, 400, 1, true, 'A', 'B', base),
    mk(41, 400, 1, false, 'A', 'B', base + 7200),
    mk(42, 400, 1, true, 'A', 'B', base + 14400)         // 2:1
  ]);
  assert('T6: series_type=1 三场 2:1 → BO3', bo3[0].boType === 'BO3', '实际: ' + bo3[0].boType);

  const sweep = resolveAll([
    mk(20, 300, 1, true, 'A', 'B', base),
    mk(21, 300, 1, true, 'A', 'B', base + 7200)          // 2:0 st=1 单系列、段内无平局
  ]);
  assert('T7: series_type=1 2:0 且段内无 1:1 → BO3（真 BO3 横扫）', sweep[0].boType === 'BO3', '实际: ' + sweep[0].boType);

  const bo5 = resolveAll([
    mk(50, 500, 2, true, 'A', 'B', base),
    mk(51, 500, 2, true, 'A', 'B', base + 7200),
    mk(52, 500, 2, true, 'A', 'B', base + 14400)         // 3:0
  ]);
  assert('T8: series_type=2 三场 3:0 → BO5', bo5[0].boType === 'BO5', '实际: ' + bo5[0].boType);
})();

// ===== T9/T10/T11/T12：UPCOMING/LIVE 声明类信号 =====
(function () {
  const s9 = lpSeries({ phase: 'upcoming', section: 'Group Stage', lastTime: 1786000000 });
  const ctx9 = sources.buildBoContext([s9], { boFormat: { group: 'BO2', playoff: null, grandFinal: null, default: 'BO2' } });
  sources.applyBo(s9, ctx9);
  assert('T9: UPCOMING 无 bestof + Format段 group=BO2 → BO2（S2）', s9.boType === 'BO2', '实际: ' + s9.boType);

  const s10 = lpSeries({ phase: 'upcoming', section: 'Playoffs', lastTime: 1786000000 });
  const ctx10 = sources.buildBoContext([s10], {});
  sources.applyBo(s10, ctx10);
  assert('T10: UPCOMING 无 bestof/Format + Playoffs → BO3（S6 先验）', s10.boType === 'BO3', '实际: ' + s10.boType);

  const base = Math.floor(Date.now() / 1000) - 3600;
  const s11 = lpSeries({ phase: 'live', declaredBo: 'BO3', lastTime: base, games: [{ radiant_win: true }, { radiant_win: null }] });
  const ctx11 = sources.buildBoContext([s11], {});
  sources.applyBo(s11, ctx11);
  assert('T11: LIVE 声明 BO3 + 已打 1 局 → BO3（不降 BO1）', s11.boType === 'BO3', '实际: ' + s11.boType);

  const s12 = lpSeries({
    phase: 'recent', declaredBo: 'BO2', scoreA: 2, scoreB: 1,
    games: [{ radiant_win: true }, { radiant_win: false }, { radiant_win: true }]
  });
  const ctx12 = sources.buildBoContext([s12], {});
  sources.applyBo(s12, ctx12);
  assert('T12: 声明 BO2 但已打 3 局 2:1 → 抬升 BO3（R3 一致性）', s12.boType === 'BO3', '实际: ' + s12.boType);
})();

// ===== R4：阶段边界（series_type 突变 + 日期间隔≥1天 → 切分；防小组自证污染淘汰）=====
(function () {
  const d1 = 1785369600, d5 = d1 + 4 * 86400;
  const list = resolveAll([
    mk(60, 600, 3, true, 'A', 'B', d1),
    mk(61, 600, 3, true, 'A', 'B', d1 + 7200),          // 小组 2:0 st=3
    mk(62, 601, 3, true, 'C', 'D', d1 + 86400),
    mk(63, 601, 3, false, 'C', 'D', d1 + 90000),         // 小组 1:1 st=3（od0 自证 BO2）
    mk(64, 602, 1, true, 'E', 'F', d5),
    mk(65, 602, 1, true, 'E', 'F', d5 + 7200)            // 淘汰 2:0 st=1（od1 无平局）
  ]);
  const s600 = list.find(function (s) { return s.key === 's600'; });
  const s601 = list.find(function (s) { return s.key === 's601'; });
  const s602 = list.find(function (s) { return s.key === 's602'; });
  assert('R4: 小组 2:0 (st=3) → BO2', s600.boType === 'BO2', '实际: ' + (s600 && s600.boType));
  assert('R4: 小组 1:1 (st=3) → BO2', s601.boType === 'BO2', '实际: ' + (s601 && s601.boType));
  assert('R4: 淘汰 2:0 (st=1, 阶段已切分, 无平局) → BO3', s602.boType === 'BO3', '实际: ' + (s602 && s602.boType) + ' key=' + (s602 && s602.stageKey));
})();

// ===== T13：league-detail fmt() 变换后（radiant_win → radiantWin 驼峰）仍正确数局数 =====
(function () {
  const base = 1785369600;
  const series = sources.groupSeries([
    mk(70, 700, 3, true, 'A', 'B', base),
    mk(71, 700, 3, true, 'A', 'B', base + 7200)
  ]);
  // 模拟 fmt：把 radiant_win 改名为 radiantWin（league-detail 后处理前的真实形状）
  series.forEach(function (s) {
    s.games = s.games.map(function (g) {
      const o = Object.assign({}, g);
      o.radiantWin = o.radiant_win;
      delete o.radiant_win;
      return o;
    });
  });
  const ctx = sources.buildBoContext(series, {});
  const r = sources.applyBo(series[0], ctx);
  assert('T13: fmt 变换后（radiantWin 驼峰）2:0 st=3 → BO2', r.boType === 'BO2', '实际: ' + r.boType);
})();

// ===== v2.1：uniBo / 同日自证 / LP 锚点 / 单阶段边界（T14-T19，审核 R1-R4）=====
(function () {
  const base = 1785369600;
  // T14：混合赛事（group=BO2/playoff=BO3）时间簇 2:0 st=1 无平局 → BO3（uniBo=null 不猜 default，防根因 C）
  {
    const list = resolveAll(
      [mk(80, 800, 1, true, 'A', 'B', base), mk(81, 800, 1, true, 'A', 'B', base + 7200)],
      { boFormat: { group: 'BO2', playoff: 'BO3', grandFinal: 'BO5', default: 'BO2' } }
    );
    const s800 = list.find(function (s) { return s.key === 's800'; });
    assert('T14: 混合赛事 2:0 st=1 无平局 → BO3（不被 default=BO2 污染）', s800.boType === 'BO3', '实际: ' + (s800 && s800.boType));
  }
  // T15：uniBo 赛事（group=BO3/playoff=BO3）2:0 st=1 → BO3（GotF 权威）
  {
    const list = resolveAll(
      [mk(82, 801, 1, true, 'A', 'B', base), mk(83, 801, 1, true, 'A', 'B', base + 7200)],
      { boFormat: { group: 'BO3', playoff: 'BO3', grandFinal: 'BO5', default: 'BO3' } }
    );
    const s801 = list.find(function (s) { return s.key === 's801'; });
    assert('T15: uniBo 赛事 2:0 → BO3', s801.boType === 'BO3', '实际: ' + (s801 && s801.boType));
  }
  // T16：1:1 与 2:0 不同日 → 2:0 不降级 BO2（同日粒度，审核 R4）
  {
    const d2 = base + 86400;
    const list = resolveAll([
      mk(84, 802, 1, true, 'X', 'Y', base),
      mk(85, 802, 1, false, 'X', 'Y', base + 7200),      // d1 1:1
      mk(86, 803, 1, true, 'P', 'Q', d2),
      mk(87, 803, 1, true, 'P', 'Q', d2 + 7200)          // d2 2:0（跨日，不受 d1 平局影响）
    ]);
    const s803 = list.find(function (s) { return s.key === 's803'; });
    assert('T16: 1:1 与 2:0 不同日 → 2:0 判 BO3（同日粒度）', s803.boType === 'BO3', '实际: ' + (s803 && s803.boType));
  }
  // T17：LP 锚点归属 playoff → S2 playoff=BO3（阶段锚点 + 时间窗）
  {
    const s = lpSeries({ phase: 'recent', section: '', lastTime: base, scoreA: 2, scoreB: 0, games: [{ radiant_win: true }, { radiant_win: true }] });
    const ctx = sources.buildBoContext([s], {
      boFormat: { group: 'BO2', playoff: 'BO3', grandFinal: 'BO5' },
      liqStages: [{ section: 'Playoffs', startTime: base }]
    });
    sources.applyBo(s, ctx);
    assert('T17: LP 锚点归属 playoff 2:0 → BO3', s.boType === 'BO3', '实际: ' + s.boType + ' stageKey=' + s.stageKey);
  }
  // T18：1:1 在 uniBo=BO3 权威下 → 不自证降级，S5 兜底 BO2（数据异常诚实显示）
  {
    const s = lpSeries({ phase: 'recent', section: '', lastTime: base, scoreA: 1, scoreB: 1, games: [{ radiant_win: true }, { radiant_win: false }] });
    const ctx = sources.buildBoContext([s], { boFormat: { group: 'BO3', playoff: 'BO3', grandFinal: 'BO5' } });
    sources.applyBo(s, ctx);
    assert('T18: 1:1 + uniBo=BO3 权威 → S5 兜底 BO2', s.boType === 'BO2', '实际: ' + s.boType);
  }
  // T19：单阶段 Format 段（仅 group=BO2，无 playoff）→ uniBo=null（审核 R3 边界）
  {
    const s = lpSeries({ phase: 'upcoming', section: 'Group Stage', lastTime: base + 86400 });
    const ctx = sources.buildBoContext([s], { boFormat: { group: 'BO2' } });
    assert('T19: 仅 group 声明 → uniBo=null（退化启发式）', ctx.uniBo === null, '实际: ' + ctx.uniBo);
  }
})();

// ===== T20/T21/T22：LP live 卡吸收 OpenDota 已结算局（v1.1 实施，审核 R3/R4/R5/R6）=====
// 场景：1win Essence II BetBoom vs OG —— OpenDota 8928712123 已结算（radiant_win=false，radiant=2586976=OG / dire=8255888），
//       LP live 卡 matchIds=[8928712123]、team1='BetBoom Team'/team2='OG'；curation 单点 2586976=OG → 方向 radiant=team2 → 比分 1:0（BetBoom 视角）
(function () {
  const openSeries = [{
    key: 's1127333',
    phase: 'recent',
    games: [
      { match_id: 8928712123, radiant_win: false, radiant_team_id: 2586976, dire_team_id: 8255888, radiant_team_name: null, dire_team_name: null }
    ]
  }];
  function mkCard() {
    return {
      key: 'liq-betboomteam__og-1785920400',
      phase: 'live', team1Name: 'BetBoom Team', team2Name: 'OG',
      matchIds: [8928712123], score1: 0, score2: 0, boType: 'BO3', games: []
    };
  }
  // T20：curation 单点定向 → 吸收 1 局，比分 1:0（team1=BetBoom 视角），aWin 正确，absorbedKeys 命中
  const r20 = sources.absorbSettledGames([openSeries[0]], [mkCard()], function (id) {
    return id === 2586976 ? 'OG' : null;
  });
  const card20 = r20.liqSeries[0];
  assert('T20: 吸收后 games 注入 1 局', card20.games.length === 1, '实际: ' + card20.games.length);
  assert('T20: 比分 1:0（team1=BetBoom 视角，games 重算）', card20.scoreA === 1 && card20.scoreB === 0, '实际: ' + card20.scoreA + '-' + card20.scoreB);
  assert('T20: aWin=team1 赢（radiant_win=false → OG 输 → BetBoom 赢）',
    card20.games[0].aWin === true && card20.games[0].bWin === false, '实际 aWin=' + card20.games[0].aWin);
  assert('T20: radiantTeamId=team1 对应 dire(8255888)', card20.radiantTeamId === 8255888, '实际: ' + card20.radiantTeamId);
  assert('T20: absorbedKeys 含 s1127333', r20.absorbedKeys.length === 1 && r20.absorbedKeys[0] === 's1127333', '实际: ' + JSON.stringify(r20.absorbedKeys));
  // T21：方向失败（resolver 全 null）→ 不注入 games、不吸收（R6 跨 tab 双卡边界）
  const r21 = sources.absorbSettledGames([openSeries[0]], [mkCard()], function () { return null; });
  assert('T21: 方向失败不注入 games', r21.liqSeries[0].games.length === 0, '实际: ' + r21.liqSeries[0].games.length);
  assert('T21: 方向失败 absorbedKeys 为空', r21.absorbedKeys.length === 0, '实际: ' + JSON.stringify(r21.absorbedKeys));
  // T22：fmt 驼峰字段兼容（radiantWin/radiantTeamId）+ 换边双局 → score 1:1（9001 OG 赢 / 9002 换边 BB 赢）
  //   验证：aWin/bWin 按 team1=BetBoom 视角，9001（radiant=OG）→ bWin；9002（radiant=BB）→ aWin
  const open2 = [{
    key: 's200', phase: 'recent',
    games: [
      { match_id: 9001, radiantWin: true, radiantTeamId: 2586976, direTeamId: 8255888 },
      { match_id: 9002, radiantWin: true, radiantTeamId: 8255888, direTeamId: 2586976 }  // 换边局：radiant=BB 赢 → team1 赢
    ]
  }];
  const r22 = sources.absorbSettledGames([open2[0]], [{
    key: 'liq-betboomteam__og-1785920400',
    phase: 'live', team1Name: 'BetBoom Team', team2Name: 'OG',
    matchIds: [9001, 9002], score1: 0, score2: 0, boType: 'BO3', games: []
  }], function (id) {
    return id === 2586976 ? 'OG' : null;
  });
  assert('T22: fmt 驼峰字段 + 换边双局 → score 1:1（team1 视角）', r22.liqSeries[0].scoreA === 1 && r22.liqSeries[0].scoreB === 1,
    '实际: ' + r22.liqSeries[0].scoreA + '-' + r22.liqSeries[0].scoreB);
  assert('T22: 9001 radiant=OG 赢 → team2 赢 → bWin', r22.liqSeries[0].games[0].aWin === false && r22.liqSeries[0].games[0].bWin === true,
    '实际 aWin=' + r22.liqSeries[0].games[0].aWin + ' bWin=' + r22.liqSeries[0].games[0].bWin);
  assert('T22: 9002 换边 radiant=BB 赢 → team1 赢 → aWin', r22.liqSeries[0].games[1].aWin === true && r22.liqSeries[0].games[1].bWin === false,
    '实际 aWin=' + r22.liqSeries[0].games[1].aWin + ' bWin=' + r22.liqSeries[0].games[1].bWin);
})();

// ===== T23：LIVE 低频重拉 OpenDota 决策（v1.1，审核 R5）=====
(function () {
  var base = 1785920400;
  assert('T23: 有 live 卡且超 5min → 重拉', sources.shouldRefreshOpenDota(1, base, base + 301) === true,
    '实际: ' + sources.shouldRefreshOpenDota(1, base, base + 301));
  assert('T23: 有 live 卡未超 5min → 不重拉', sources.shouldRefreshOpenDota(1, base, base + 299) === false,
    '实际: ' + sources.shouldRefreshOpenDota(1, base, base + 299));
  assert('T23: 有 live 卡刚好 5min → 重拉', sources.shouldRefreshOpenDota(1, base, base + 300) === true,
    '实际: ' + sources.shouldRefreshOpenDota(1, base, base + 300));
  assert('T23: 无 live 卡 → 永不重拉', sources.shouldRefreshOpenDota(0, 0, base) === false,
    '实际: ' + sources.shouldRefreshOpenDota(0, 0, base));
  assert('T23: 首次（last=0）→ 重拉', sources.shouldRefreshOpenDota(1, 0, base) === true,
    '实际: ' + sources.shouldRefreshOpenDota(1, 0, base));
})();

// ===== T24：页面 map 输出形状契约（v1.1 二次修复，防吸收字段再丢失）=====
// 实证根因：页面 liqSeries map 曾缺 matchIds/team1Name/team2Name → absorbSettledGames 恒跳过 → LIVE 0:0。
// 本用例固化「页面透传后形状必须注入」+「兜底（仅 radiantName）也能定向」+「无 matchIds 守卫跳过」。
(function () {
  var openSeries = [{
    key: 's1127333', phase: 'recent',
    games: [
      { match_id: 8928712123, radiant_win: false, radiant_team_id: 2586976, dire_team_id: 8255888 },
      { match_id: 8928813748, radiant_win: false, radiant_team_id: 8255888, dire_team_id: 2586976 }
    ]
  }];
  function resolver(id) { return id === 2586976 ? 'OG' : null; }
  function mkCard(extra) {
    var c = { key: 'liq-betboomteam__og-1785834000', games: [], phase: 'live',
      matchIds: [8928712123, 8928813748], team1Name: 'BetBoom Team', team2Name: 'OG',
      radiantName: 'BetBoom Team', direName: 'OG', scoreA: 0, scoreB: 0,
      radiantTeamId: 0, direTeamId: 0, boType: 'BO3', lastTime: 1785834000 };
    return Object.assign({}, c, extra || {});
  }
  // ① 页面透传后完整形状 → 注入 1:1 + absorbedKeys
  var r1 = sources.absorbSettledGames([openSeries[0]], [mkCard()], resolver);
  assert('T24: 页面透传形状 → games=2 score=1:1', r1.liqSeries[0].games.length === 2 && r1.liqSeries[0].scoreA === 1 && r1.liqSeries[0].scoreB === 1,
    '实际: games=' + r1.liqSeries[0].games.length + ' score=' + r1.liqSeries[0].scoreA + '-' + r1.liqSeries[0].scoreB);
  assert('T24: absorbedKeys 含被吸收卡', r1.absorbedKeys.length === 1 && r1.absorbedKeys[0] === 's1127333',
    '实际: ' + JSON.stringify(r1.absorbedKeys));
  // ② 兜底：无 team1Name/team2Name（仅 radiantName/direName）→ 也能定向注入
  var r2 = sources.absorbSettledGames([openSeries[0]], [mkCard({ team1Name: undefined, team2Name: undefined })], resolver);
  assert('T24: radiantName 兜底 → 仍注入 1:1', r2.liqSeries[0].games.length === 2 && r2.liqSeries[0].scoreA === 1,
    '实际: games=' + r2.liqSeries[0].games.length + ' score=' + r2.liqSeries[0].scoreA + '-' + r2.liqSeries[0].scoreB);
  // ③ 无 matchIds（页面早期形状）→ 守卫跳过不注入（R6 边界）
  var r3 = sources.absorbSettledGames([openSeries[0]], [mkCard({ matchIds: [] })], resolver);
  assert('T24: 无 matchIds → 守卫跳过', r3.liqSeries[0].games.length === 0 && r3.absorbedKeys.length === 0,
    '实际: games=' + r3.liqSeries[0].games.length);
})();

// ===== T25：吸收方向解析 resolver 三路径（v3.1，审核 R6）=====
// 场景：GotF PlayTime vs Team Resilience —— 第一局 radiant=PlayTime(10207983) win=true = 1:0（PlayTime 视角）
// ① explorer 名 resolver（load 预取 map）→ 注入 + 方向正确；② curation 兜底（explorer 空 + curation 有 OG）→ 仍注入；
// ③ 全 null（curation/explorer/raw 皆无）→ 守卫不注入（0:0 诚实降级）
(function () {
  var openSeries = [{
    key: 's1127341', phase: 'recent',
    games: [
      { match_id: 8928851109, radiant_win: true, radiant_team_id: 10207983, dire_team_id: 10207984 }  // radiant=PlayTime 赢
    ]
  }];
  function mkCard() {
    return { key: 'liq-playtime__teamresilience-1785826800', games: [], phase: 'live',
      matchIds: [8928851109], team1Name: 'PlayTime', team2Name: 'Team Resilience',
      radiantName: 'PlayTime', direName: 'Team Resilience', scoreA: 0, scoreB: 0,
      radiantTeamId: 0, direTeamId: 0, boType: 'BO3', lastTime: 1785826800 };
  }
  // ① explorer 名 resolver（v3.1 R1 可靠源）
  var r1 = sources.absorbSettledGames([openSeries[0]], [mkCard()], function (id) {
    return id === 10207983 ? 'PlayTime' : (id === 10207984 ? 'Team resilience' : null);
  });
  assert('T25①: explorer 名 → 注入 1 局', r1.liqSeries[0].games.length === 1, '实际: ' + r1.liqSeries[0].games.length);
  assert('T25①: 方向 radiant=PlayTime=team1 赢 → scoreA=1', r1.liqSeries[0].scoreA === 1 && r1.liqSeries[0].scoreB === 0,
    '实际: ' + r1.liqSeries[0].scoreA + '-' + r1.liqSeries[0].scoreB);
  assert('T25①: aWin=team1（PlayTime 赢）', r1.liqSeries[0].games[0].aWin === true && r1.liqSeries[0].games[0].bWin === false,
    '实际 aWin=' + r1.liqSeries[0].games[0].aWin);
  assert('T25①: absorbedKeys 含 s1127341', r1.absorbedKeys.length === 1, '实际: ' + JSON.stringify(r1.absorbedKeys));
  // ② curation 兜底（explorer map 空、curation 有 OG → 单点定向）
  var open2 = [{ key: 's1127333', phase: 'recent', games: [
    { match_id: 8928712123, radiant_win: false, radiant_team_id: 2586976, dire_team_id: 8255888 }
  ] }];
  var r2 = sources.absorbSettledGames([open2[0]], [{ key: 'liq-betboomteam__og-1785834000', games: [], phase: 'live',
    matchIds: [8928712123], team1Name: 'BetBoom Team', team2Name: 'OG', radiantName: 'BetBoom Team', direName: 'OG',
    scoreA: 0, scoreB: 0, radiantTeamId: 0, direTeamId: 0, boType: 'BO3', lastTime: 1785834000 }],
    function (id) { return id === 2586976 ? 'OG' : null; });
  assert('T25②: curation 兜底（explorer 空 + OG）→ 注入 1:0', r2.liqSeries[0].games.length === 1 && r2.liqSeries[0].scoreA === 1,
    '实际: games=' + r2.liqSeries[0].games.length + ' score=' + r2.liqSeries[0].scoreA + '-' + r2.liqSeries[0].scoreB);
  // ③ 全 null（curation/explorer/raw 皆无）→ 守卫不注入（0:0 诚实降级）
  var r3 = sources.absorbSettledGames([openSeries[0]], [mkCard()], function () { return null; });
  assert('T25③: 全 null → 守卫不注入', r3.liqSeries[0].games.length === 0 && r3.absorbedKeys.length === 0,
    '实际: games=' + r3.liqSeries[0].games.length);
})();

// ===== T26/T27：S1 第二关联键 —— matchIds 空 + 队名 + 时间窗（v1.1，审核 R1-R6）=====
// 场景：GotF Team Resilience vs Rune Eaters —— LP 未填 matchid（matchIds=[]），OpenDota series 1127601 单局已结算
// T26：matchIds 空 + live + 队名/时间窗命中 → 注入 1:0（fmt 后真实形状：game 无 start_time、series 有 firstTime，R1/R6）
// T27：① upcoming 卡队名匹配 → 不关联（R2 守卫）；② live 卡超窗（5h > 4h）→ 不关联（R5 回归）
(function () {
  // groupSeries 输出形状（R1：系列含 firstTime；games 为原始 match 形状）
  var openSeries = [{
    key: 's1127601', phase: 'recent',
    firstTime: 1785917258,   // 2026-08-05 08:07:38 UTC
    lastTime: 1785917258,
    games: [
      { match_id: 8930200713, radiant_win: true, radiant_team_id: 10207984, dire_team_id: 10207961 }
    ]
  }];
  function mkCard(phase, lastTime, matchIds) {
    return { key: 'liq-teamresilience__runeeaters-' + (lastTime || 0), games: [], phase: phase,
      matchIds: matchIds || [], team1Name: 'Team Resilience', team2Name: 'Rune Eaters',
      radiantName: 'Team Resilience', direName: 'Rune Eaters', scoreA: 0, scoreB: 0,
      radiantTeamId: 0, direTeamId: 0, boType: 'BO1', lastTime: lastTime || 0 };
  }
  var resolver = function (id) {
    return id === 10207984 ? 'Team Resilience' : (id === 10207961 ? 'Rune Eaters' : null);
  };
  // T26：live + matchIds 空 + 队名/时间窗命中（差 7 分钟 ≤ 4h）→ 注入 1:0
  var r26 = sources.absorbSettledGames([openSeries[0]], [mkCard('live', 1785917258 + 420, [])], resolver);
  assert('T26: S1 live+队名+时间窗 → 注入 1 局', r26.liqSeries[0].games.length === 1,
    '实际: games=' + r26.liqSeries[0].games.length);
  assert('T26: 方向 radiant=Team Resilience=team1 赢 → scoreA=1', r26.liqSeries[0].scoreA === 1 && r26.liqSeries[0].scoreB === 0,
    '实际: score=' + r26.liqSeries[0].scoreA + '-' + r26.liqSeries[0].scoreB);
  assert('T26: absorbedKeys 含 s1127601（RECENT 卡移除）', r26.absorbedKeys.length === 1 && r26.absorbedKeys[0] === 's1127601',
    '实际: ' + JSON.stringify(r26.absorbedKeys));
  // T27①：upcoming 卡队名匹配（matchIds 空）→ S1 不关联（R2 守卫）
  var r27a = sources.absorbSettledGames([openSeries[0]], [mkCard('upcoming', 1785917258 + 3600, [])], resolver);
  assert('T27①: upcoming 卡 → 不关联（R2 守卫）', (r27a.liqSeries[0].games || []).length === 0 && r27a.absorbedKeys.length === 0,
    '实际: games=' + (r27a.liqSeries[0].games || []).length + ' absorbed=' + JSON.stringify(r27a.absorbedKeys));
  // T27②：live 卡超窗（5h > 4h）→ 不关联（R5）
  var r27b = sources.absorbSettledGames([openSeries[0]], [mkCard('live', 1785917258 + 5 * 3600, [])], resolver);
  assert('T27②: 超窗 5h → 不关联（R5 回归）', (r27b.liqSeries[0].games || []).length === 0 && r27b.absorbedKeys.length === 0,
    '实际: games=' + (r27b.liqSeries[0].games || []).length + ' absorbed=' + JSON.stringify(r27b.absorbedKeys));
  // T27③：S0 互斥回归 —— matchIds 有值（含不命中）不降级 S1（R3）；此处不命中 → 不注入
  var r27c = sources.absorbSettledGames([openSeries[0]], [mkCard('live', 1785917258 + 420, [999999999])], resolver);
  assert('T27③: matchIds 有值但不命中 → 不降级 S1（R3）', (r27c.liqSeries[0].games || []).length === 0 && r27c.absorbedKeys.length === 0,
    '实际: games=' + (r27c.liqSeries[0].games || []).length + ' absorbed=' + JSON.stringify(r27c.absorbedKeys));
})();

// ===== T29/T30：队名模糊匹配升级（v1.1，审核 R2/R5）=====
// 场景：1win Essence II 半决赛 —— LP 名 '1w Team'/'BetBoom Team' vs OpenDota explorer 名 '1w'/'BoomBoys'
// T29①：explorer 名 + 去后缀（1w→1wteam）→ 注入 1:1；T29②：curation 权威名 → 同样注入；
// T29③：换边局 team_id 归属正确；T30：公共子串反例（navi/navijr、heroic/hero 不误配，审核 R1）
(function () {
  var openSeries = [{
    key: 's1127604', phase: 'recent',
    firstTime: 1785920619, lastTime: 1785925419,
    games: [
      { match_id: 8930248124, radiant_win: true, radiant_team_id: 8255888, dire_team_id: 10182357 },
      { match_id: 8930324653, radiant_win: false, radiant_team_id: 8255888, dire_team_id: 10182357 }
    ]
  }];
  function mkCard() {
    return { key: 'liq-1wteam__betboomteam-1785981200', games: [], phase: 'live',
      matchIds: [8930248124, 8930324653], team1Name: '1w Team', team2Name: 'BetBoom Team',
      radiantName: '1w Team', direName: 'BetBoom Team', scoreA: 0, scoreB: 0,
      radiantTeamId: 0, direTeamId: 0, boType: 'BO3', lastTime: 1785981200 };
  }
  // ① explorer 名 resolver（无 curation）——1w 靠去后缀命中定向，BoomBoys 靠补集原理不匹配
  var r29a = sources.absorbSettledGames([openSeries[0]], [mkCard()], function (id) {
    return id === 8255888 ? 'BoomBoys' : (id === 10182357 ? '1w' : null);
  });
  assert('T29①: explorer 名（BoomBoys/1w）+ 去后缀 → 注入 2 局 1:1', r29a.liqSeries[0].games.length === 2 && r29a.liqSeries[0].scoreA === 1 && r29a.liqSeries[0].scoreB === 1,
    '实际: games=' + r29a.liqSeries[0].games.length + ' score=' + r29a.liqSeries[0].scoreA + '-' + r29a.liqSeries[0].scoreB);
  assert('T29①: absorbedKeys 含 s1127604（RECENT 卡移除）', r29a.absorbedKeys.length === 1 && r29a.absorbedKeys[0] === 's1127604',
    '实际: ' + JSON.stringify(r29a.absorbedKeys));
  // ② curation 名 resolver（BetBoom Team/1w Team 权威名）——应同样吸收
  var r29b = sources.absorbSettledGames([openSeries[0]], [mkCard()], function (id) {
    return id === 8255888 ? 'BetBoom Team' : (id === 10182357 ? '1w Team' : null);
  });
  assert('T29②: curation 名（BetBoom Team/1w Team）→ 注入 1:1', r29b.liqSeries[0].games.length === 2 && r29b.liqSeries[0].scoreA === 1,
    '实际: games=' + r29b.liqSeries[0].games.length + ' score=' + r29b.liqSeries[0].scoreA + '-' + r29b.liqSeries[0].scoreB);
  // ③ 完整吸收：换边局按 team_id 归属（第一局 8255888 赢=BetBoom、第二局 10182357 赢=1w → 1:1）
  assert('T29③: 换边局 aWin/bWin 正确（1w 视角 1:1）',
    r29a.liqSeries[0].games[0].aWin === false && r29a.liqSeries[0].games[0].bWin === true &&
    r29a.liqSeries[0].games[1].aWin === true && r29a.liqSeries[0].games[1].bWin === false,
    '实际: ' + r29a.liqSeries[0].games.map(function (g) { return g.aWin + '/' + g.bWin; }).join(', '));
  // T30：公共子串反例（审核 R1 防回归）——验证「任意位置公共子串」不误配
  // ① BoomBoys vs BetBoom Team：中间共享 'boom'（非前缀/后缀完整包含）→ 不应误配
  //    （若误配则方向错乱；正确行为是 nameMatch false，靠 curation 别名关联）
  // ② 短名 2 字符不参与子串：'og' 出现在任意队名中间 → 不应命中
  var open30 = [{ key: 's999', phase: 'recent', firstTime: 1786000000, lastTime: 1786000000,
    games: [{ match_id: 999001, radiant_win: true, radiant_team_id: 9991, dire_team_id: 9992 }] }];
  // dire 侧 resolver 返回与 LP 两队都无关的名字（防精确命中干扰 radiant 侧断言）
  var r30a = sources.absorbSettledGames([open30[0]], [{ key: 'liq-betboom-1', games: [], phase: 'live',
    matchIds: [999001], team1Name: 'BetBoom Team', team2Name: 'Gamma Squad', radiantName: 'BetBoom Team', direName: 'Gamma Squad',
    scoreA: 0, scoreB: 0, radiantTeamId: 0, direTeamId: 0, boType: 'BO1', lastTime: 1786000000 }],
    function (id) { return id === 9991 ? 'BoomBoys' : (id === 9992 ? 'Zeta Nine' : null); });
  assert('T30①: BoomBoys vs BetBoom Team 中间子串不误配（R1）', (r30a.liqSeries[0].games || []).length === 0 && r30a.absorbedKeys.length === 0,
    '实际: games=' + (r30a.liqSeries[0].games || []).length + ' absorbed=' + JSON.stringify(r30a.absorbedKeys));
  // ② 短名 'og'（2 字符）不出现在任意队名子串匹配：radiant=OG vs team1='Dragon Knights'（含 og）
  var r30b = sources.absorbSettledGames([open30[0]], [{ key: 'liq-dragon-1', games: [], phase: 'live',
    matchIds: [999001], team1Name: 'Dragon Knights', team2Name: 'Gamma Squad', radiantName: 'Dragon Knights', direName: 'Gamma Squad',
    scoreA: 0, scoreB: 0, radiantTeamId: 0, direTeamId: 0, boType: 'BO1', lastTime: 1786000000 }],
    function (id) { return id === 9991 ? 'OG' : (id === 9992 ? 'Zeta Nine' : null); });
  assert('T30②: 短名 og 不参与子串匹配（下限 3）', (r30b.liqSeries[0].games || []).length === 0 && r30b.absorbedKeys.length === 0,
    '实际: games=' + (r30b.liqSeries[0].games || []).length + ' absorbed=' + JSON.stringify(r30b.absorbedKeys));
})();

// ===== T31：RECENT 同对局双卡修复（审核 R2/R5，基于纯函数断言）=====
(function () {
  var idSet = new Set(['8929037896', '8929156216', '8930248124']);
  // T31①：matchIds 全命中 → true（LP recent 卡剔除 → 单卡）
  assert('T31①: allMatchIdsInSet 全命中 → true', sources.allMatchIdsInSet([8929037896, 8929156216], idSet) === true,
    '实际: ' + sources.allMatchIdsInSet([8929037896, 8929156216], idSet));
  // T31②：live/upcoming 卡早退（filter 语义）；纯函数层面 = 空/不命中不剔除
  assert('T31②: 空 matchIds → false（不剔除）', sources.allMatchIdsInSet([], idSet) === false,
    '实际: ' + sources.allMatchIdsInSet([], idSet));
  assert('T31②b: 全不命中 → false（不剔除）', sources.allMatchIdsInSet([999999], idSet) === false,
    '实际: ' + sources.allMatchIdsInSet([999999], idSet));
  // T31③：部分命中 → false（保留 LP 卡；双卡残留为可接受边界 R3）
  assert('T31③: 部分命中 → false（双卡残留边界）', sources.allMatchIdsInSet([8929037896, 999999], idSet) === false,
    '实际: ' + sources.allMatchIdsInSet([8929037896, 999999], idSet));
  // T31④：resolveTeamIdName 解名链（explorer 优先 → curation → raw idMap）
  var nameMap = { 726228: 'Vici Gaming', 10182357: '1w' };
  var curated = { 10182357: { name: '1w Team' } };
  assert('T31④a: explorer 优先解名', sources.resolveTeamIdName(726228, nameMap, {}, {}) === 'Vici Gaming',
    '实际: ' + sources.resolveTeamIdName(726228, nameMap, {}, {}));
  assert('T31④b: curation 兜底解名', sources.resolveTeamIdName(10182357, {}, curated, {}) === '1w Team',
    '实际: ' + sources.resolveTeamIdName(10182357, {}, curated, {}));
  assert('T31④c: raw idMap 兜底解名', sources.resolveTeamIdName(10182357, {}, {}, { 10182357: '1w' }) === '1w',
    '实际: ' + sources.resolveTeamIdName(10182357, {}, {}, { 10182357: '1w' }));
  // T31④d（R5）：解名后精确去重键匹配（去后缀 + 顺序无关 k/kRev）——OpenDota '1w'/'Vici Gaming' vs LP '1w Team'/'Vici Gaming'
  function normDedup(name) {
    var n = String(name).toLowerCase().trim();
    n = n.replace(/\s*(esports|e-sports|gaming|team|club)\s*$/g, '');
    n = n.replace(/[^a-z0-9\u4e00-\u9fff\u0430-\u044f\u0451]/g, '');
    return n;
  }
  var openK = normDedup('1w') + '__' + normDedup('Vici Gaming');            // 1w__vici
  var lpKRev = normDedup('Vici Gaming') + '__' + normDedup('1w Team');      // vici__1w → 反转
  lpKRev = lpKRev.split('__').reverse().join('__');                         // 1w__vici
  assert('T31④d: 精确键匹配（R5，顺序无关）', openK === lpKRev, '实际: openK=' + openK + ' lpKRev=' + lpKRev);
  // T31⑤：全空 → null（回退占位无害）
  assert('T31⑤: 全空解名 → null', sources.resolveTeamIdName(999999, {}, {}, {}) === null,
    '实际: ' + sources.resolveTeamIdName(999999, {}, {}, {}));
})();

// ===== T32：账号登录纯函数（2026-08-07，审核 R5；auth.ensureOpenId 依赖 wx 不可直接单测）=====
(function () {
  var auth = require('../utils/auth.js');
  // T32①：isValidOpenId 结构校验
  assert('T32①a: 长 openid 合法', auth.isValidOpenId('oABC1234567890') === true,
    '实际: ' + auth.isValidOpenId('oABC1234567890'));
  assert('T32①b: 短串不合法（<=10）', auth.isValidOpenId('o123') === false,
    '实际: ' + auth.isValidOpenId('o123'));
  assert('T32①c: 非字符串不合法', auth.isValidOpenId(123456789012) === false && auth.isValidOpenId(null) === false,
    '实际: ' + auth.isValidOpenId(123456789012) + '/' + auth.isValidOpenId(null));
  // T32②：mergeSubs 云端有值优先（本地为空才保留本地）
  var cloudSubs = { T1: { subscribed: true, time: 100, lastStatus: 'accept' } };
  var localSubs = { T2: { subscribed: true, time: 200 } };
  var merged = auth.mergeSubs(cloudSubs, localSubs);
  assert('T32②a: 云端有值 → 覆盖本地同 key', merged.T1 && merged.T1.time === 100,
    '实际: ' + JSON.stringify(merged.T1));
  assert('T32②b: 本地独有 key 保留', merged.T2 && merged.T2.time === 200,
    '实际: ' + JSON.stringify(merged.T2));
  var merged2 = auth.mergeSubs(cloudSubs, null);
  assert('T32②c: 本地为空 → 全用云端', merged2.T1 && merged2.T1.subscribed === true && Object.keys(merged2).length === 1,
    '实际: ' + JSON.stringify(merged2));
  var merged3 = auth.mergeSubs(null, localSubs);
  assert('T32②d: 云端为空 → 保本地', merged3.T2 && merged3.T2.time === 200,
    '实际: ' + JSON.stringify(merged3));
  var merged4 = auth.mergeSubs({ T3: { subscribed: false, time: 300 } }, localSubs);
  assert('T32②e: 云端未授权（subscribed=false）→ 不覆盖本地', merged4.T3 === undefined && merged4.T2,
    '实际: ' + JSON.stringify(merged4));
})();

// ===== 真实数据回放（可选）：1win(20009) / GotF(19917)，两态（无/有 boFormat，审核 R5）=====
(function () {
  var fs = require('fs');
  var files = [
    ['1win Essence II (20009)', 'D:/tmp/od_1win.json', '/tmp/od_1win.json',
      { group: 'BO2', playoff: 'BO3', grandFinal: 'BO5', default: 'BO2' }],
    ['The Games of the Future 2026 (19917)', 'D:/tmp/od_gotf.json', '/tmp/od_gotf.json',
      { group: 'BO3', playoff: 'BO3', grandFinal: 'BO5', default: 'BO3' }]
  ];
  files.forEach(function (f) {
    var path = fs.existsSync(f[1]) ? f[1] : (fs.existsSync(f[2]) ? f[2] : null);
    if (!path) { console.log('SKIP  ' + f[0] + ' 真实数据回放（文件不存在）'); return; }
    var matches = require(path);
    function replay(boFormat) {
      var series = sources.groupSeries(matches);
      var ctx = sources.buildBoContext(series, boFormat ? { boFormat: boFormat } : {});
      var res = series.map(function (s) { return sources.applyBo(s, ctx); });
      var cnt = {};
      res.forEach(function (s) { cnt[s.boType] = (cnt[s.boType] || 0) + 1; });
      return { series: series, res: res, cnt: cnt };
    }
    var noCloud = replay(null);      // 态 A：未部署云函数（无 boFormat）
    var withCloud = replay(f[3]);    // 态 B：已部署（uniBo 权威）
    console.log('回放  ' + f[0] + ' | 态A(未部署)=' + JSON.stringify(noCloud.cnt) + ' | 态B(已部署)=' + JSON.stringify(withCloud.cnt));
    // 断言 1：series_type=3（BO2）系列两态都无 2:0 误判 BO3
    [noCloud, withCloud].forEach(function (r) {
      var st3Bad = r.series.filter(function (s) {
        return s.seriesType === 3 && r.res.find(function (x) { return x.key === s.key; }).boType === 'BO3' &&
          (s.scoreA === 2 || s.scoreB === 2);
      });
      assert('回放 ' + f[0] + ': st=3 系列无 2:0 误判 BO3', st3Bad.length === 0);
    });
    // 断言 2：无「≥2 局却判 BO1」的已结算系列（两态）
    [noCloud, withCloud].forEach(function (r) {
      var badBo1 = r.res.filter(function (s) {
        return s.boType === 'BO1' && s.phase === 'recent' && ((s.games && s.games.length) || 0) >= 2;
      });
      assert('回放 ' + f[0] + ': 无 ≥2 局判 BO1', badBo1.length === 0);
    });
    // 断言 3（用户痛点，审核 R1 边界表）：GotF 态 A 的 8/2 淘汰 0:2（s1126935）→ BO3
    if (f[0].indexOf('GotF') >= 0) {
      var s6935 = noCloud.res.find(function (s) { return s.key === 's1126935'; });
      assert('回放 GotF 态A: Playoffs 8/2 0:2 (s1126935) → BO3', s6935 && s6935.boType === 'BO3', '实际: ' + (s6935 && s6935.boType));
      // 态 B（已部署）：uniBo=BO3 → 全赛事仅 1:1 异常为 BO2
      assert('回放 GotF 态B: BO2 仅剩 1 个（1:1 数据异常）', withCloud.cnt.BO2 === 1, '实际: ' + withCloud.cnt.BO2);
    }
    // 断言 4（审核 R1 边界表）：1win 两态零回归（小组 BO2×18 / 淘汰 BO3×4）
    if (f[0].indexOf('1win') >= 0) {
      assert('回放 1win 态A: 零回归 BO2=18/BO3=4', noCloud.cnt.BO2 === 18 && noCloud.cnt.BO3 === 4, JSON.stringify(noCloud.cnt));
      assert('回放 1win 态B: 零回归 BO2=18/BO3=4（uniBo=null 不污染淘汰）', withCloud.cnt.BO2 === 18 && withCloud.cnt.BO3 === 4, JSON.stringify(withCloud.cnt));
    }
  });
})();

console.log('\n=== 结果 ===');
console.log('通过: ' + pass + '  失败: ' + fail);
if (fail > 0) process.exit(1);
console.log('全部通过 ✅');
